/**
 * Contains classes representing a sample ad network.
 */
package com.google.ads.mediation.sample.sdk;