Example Mediation Adapter
=========================

This is an example implementation for a mediation adapter for Google Mobile Ads
on Android using the new mediation adapter APIs introduced in Google Play
services 4.4.

This example helps ad networks build a mediation adapter. If you are an app
developer looking to integrate Google Mobile Ads into your mobile apps, check
out the
[Android examples](https://github.com/googleads/googleads-mobile-android-examples)
instead.

